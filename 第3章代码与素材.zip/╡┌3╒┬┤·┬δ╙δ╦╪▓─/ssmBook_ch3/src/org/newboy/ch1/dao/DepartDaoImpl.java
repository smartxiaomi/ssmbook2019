package org.newboy.ch1.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.newboy.ch1.BaseDao;
import org.newboy.news.bean.Depart;
import org.newboy.news.bean.User;

public class DepartDaoImpl extends BaseDao implements DepartDao {

	public List<Depart> getAllDepart() {
		List<Depart> list =new ArrayList<Depart>();
		String sql="select * from scott.dept";
		con = super.getCon();

		try {
			ps = super.con.prepareStatement(sql);
			super.rs = ps.executeQuery();
			while (rs.next()) {
			int dno =rs.getInt("DEPTNO");
			String dname=rs.getString("dname");
			String location=rs.getString("loc");
			Depart depart =new Depart(dno,dname,location);
			list.add(depart);
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, con);
		}
		return list;
	}

	/**
	 * ���id��ѯĳ�����ŵ���Ϣ
	 */
	public Depart getDepartById(int dno) {
		Depart depart=null;
		String sql="select * from scott.dept where dno=?";
		con = super.getCon();

		try {
			ps = super.con.prepareStatement(sql);
			ps.setInt(1, dno);
			super.rs = ps.executeQuery();
			if (rs.next()) {
			String dname=rs.getString("dname");
			String location=rs.getString("loc");
			depart=new Depart(dno, dname, location);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, con);
		}// TODO Auto-generated method stub
		return depart;
	}

}
