package org.newboy.ch1.dao;

import java.sql.SQLException;

import org.newboy.ch1.BaseDao;
import org.newboy.news.bean.User;

public class UserDaoImpl extends BaseDao implements UserDao {

	// 
	public User getUserByNamepwd(String uname, String passwd) {
		User user = null;
		String sql = "select * from tbl_user where uname=? and upassword=?";
		con = super.getCon();

		try {
			ps = super.con.prepareStatement(sql);

			ps.setString(1, uname);
			ps.setString(2, passwd);

			super.rs = ps.executeQuery();
			if (rs.next()) {
				user = new User(uname, passwd);
				user.setUid(rs.getString("userid"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			super.closeAll(rs, ps, con);
		}
		return user;
	}

	public int saveUser(User user) {
		// TODO Auto-generated method stub
		return 0;
	}

}
