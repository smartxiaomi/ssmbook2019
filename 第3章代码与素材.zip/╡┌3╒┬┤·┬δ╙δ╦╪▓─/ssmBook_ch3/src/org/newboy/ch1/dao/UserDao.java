package org.newboy.ch1.dao;

import org.newboy.news.bean.User;

public interface UserDao {
	
	public User getUserByNamepwd(String uname,String passwd);
	public int saveUser(User user);
	

}
