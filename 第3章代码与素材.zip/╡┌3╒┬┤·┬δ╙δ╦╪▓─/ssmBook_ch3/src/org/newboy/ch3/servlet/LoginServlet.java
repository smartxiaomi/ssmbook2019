package org.newboy.ch3.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.newboy.ch1.dao.UserDao;
import org.newboy.ch1.dao.UserDaoImpl;
import org.newboy.news.bean.User;

public class LoginServlet extends HttpServlet {
	
	//在第2章的LoginServlet中，无需读取数据库，这里是要求读取数据库的数据
       UserDao userdao =new UserDaoImpl();
       
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("uname");
		String pass = request.getParameter("upass");
		RequestDispatcher rd = null;// ��ת����
	
		// 
		 User user=userdao.getUserByNamepwd(name, pass);
		if (user!=null) {
		
			HttpSession session =request.getSession();
			session.setAttribute("loginUser", user);
			
			rd = request.getRequestDispatcher("welcome.jsp");

		} else {
			request.setAttribute("fail","用户名或密码错误");
			rd = request.getRequestDispatcher("fail.jsp");
		}
		rd.forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
