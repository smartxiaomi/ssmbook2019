package org.newboy.news.bean;

public class DepartApp {

	public static void main(String[] args) {
		Depart depart=new Depart(100, "开发部", "广州");
		System.out.println("部门编号："+depart.getDno());
		System.out.println("部门名字："+depart.getDname());
		System.out.println("部门所在城市："+depart.getLocation());
		

	}

}
