package org.newboy.news.bean;

public class Depart {

	private int dno;      // 部门编号
	private String dname; // 部门名字
	private String location;// 部门所在地址
	
	
	public Depart(int dno, String dname, String location) {
		this.dno = dno;
		this.dname = dname;
		this.location = location;
	}
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	

}
