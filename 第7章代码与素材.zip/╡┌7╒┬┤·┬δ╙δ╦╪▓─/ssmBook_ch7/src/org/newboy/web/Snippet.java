package org.newboy.web;

public class Snippet {
/*
	    <bean id="jsonConverter"  
	        class="org.springframework.http.converter.json.MappingJacksonHttpMessageConverter"></bean>  
	    <bean  
	        class="org.springframework.web.servlet.mvc.annotation.AnnotationMethodHandlerAdapter">  
	        <property name="messageConverters">  
	            <list>  
	                <ref bean="stringConverter"/>  
	                <ref bean="jsonConverter" />  
	            </list>  
	        </property>  
	    </bean>  
	    
	*/
}

