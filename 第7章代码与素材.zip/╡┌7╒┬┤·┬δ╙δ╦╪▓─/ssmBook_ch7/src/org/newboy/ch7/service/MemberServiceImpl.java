package org.newboy.ch7.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.newboy.ch7.entity.Member;
import org.springframework.stereotype.Service;
//省略import语句
@Service
public class MemberServiceImpl implements MemberService {
   //用了Map来模拟数据存储
    private Map<String, Member> members = new HashMap<String, Member>();

    public MemberServiceImpl(){
    	Member m1 =new Member("1001","张小飞","13988880000","nobody@qq.com");
    	Member m2 =new Member("1002","赵小云","13988880001","nobody2@qq.com");
    	
    	members.put(m1.getMid(), m1);//会员ID作为键
    	members.put(m2.getMid(), m2);//会员ID作为键
    }
    
    
    public void add(Member member) {
        members.put(member.getName(), member);
    }

    public void remove(String memberName) {
        members.remove(memberName);
    }

    public List<Member> list() {
        return new ArrayList<Member>(members.values());
    }
}
