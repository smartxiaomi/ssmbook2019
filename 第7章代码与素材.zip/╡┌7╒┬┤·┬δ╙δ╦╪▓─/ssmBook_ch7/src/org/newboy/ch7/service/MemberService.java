package org.newboy.ch7.service;

import java.util.List;
import org.newboy.ch7.entity.Member;


public interface MemberService {

    public void add(Member member);
    public void remove(String memberName);
    public List<Member> list();
}
