package org.newboy.dao;

import java.util.List;

import org.newboy.entity.Employee;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

/**
 * ���ݷ��ʲ㣬��DAO�еõ�JdbcTemplate����
 * 
 * @author NewBoy
 */
public class EmployeeDao extends JdbcDaoSupport {

	/**
	 * ����Ա��
	 */
	public int addEmployee(Employee employee) {
		return getJdbcTemplate().update("insert into employee values(null,?,?,?,?)", employee.getName(),
				employee.isGender(), employee.getBirthday(), employee.getDepartId()); // ע���Ա���isGender()
	}

	/**
	 * �޸�Ա��
	 */
	public int updateEmployee(Employee employee) {
		return getJdbcTemplate().update("update employee set name=?,gender=?,birthday=?,depart_id=? where id=?",
				employee.getName(), employee.isGender(), employee.getBirthday(), employee.getDepartId(),
				employee.getId());
	}

	/**
	 * ɾ��Ա��
	 */
	public int deleteEmployee(int id) {
		return getJdbcTemplate().update("delete from employee where id=?", id);
	}

	/**
	 * ��ѯ����Ա��
	 */
	public List<Employee> findAllEmployees() {
		return getJdbcTemplate().query("select * from employee", new BeanPropertyRowMapper<>(Employee.class));
	}

}
