package org.newboy.entity;

import java.io.Serializable;
import java.sql.Date;

/**
 * Ա����ʵ����
 * @author NewBoy
 */
public class Employee implements Serializable {

	private int id; // ����
	private String name; // Ա����
	private boolean gender; // �Ա�
	private Date birthday; // ����
	private int departId; // ���ڲ���

	public Employee(int id, String name, boolean gender, Date birthday, int departId) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.birthday = birthday;
		this.departId = departId;
	}

	public Employee() {
		super();
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", gender=" + gender + ", birthday=" + birthday + ", departId="
				+ departId + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isGender() {
		return gender;
	}

	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public int getDepartId() {
		return departId;
	}

	public void setDepartId(int departId) {
		this.departId = departId;
	}

}
