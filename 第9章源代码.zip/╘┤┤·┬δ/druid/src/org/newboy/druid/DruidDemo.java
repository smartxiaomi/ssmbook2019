package org.newboy.druid;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;
import javax.sql.DataSource;

import com.alibaba.druid.pool.DruidDataSourceFactory;

/**
 * druid连接池的使用
 * @author NewBoy
 *
 */
public class DruidDemo {
	public static void main(String[] args) throws Exception {
		// 加载配置文件中的配置参数
		InputStream is = DruidDemo.class.getResourceAsStream("/druid.properties");
		//创建属性对象
		Properties properties = new Properties();
		//读取配置文件中的参数
		properties.load(is);
		
		// 通过工厂对象创建数据源
		DataSource ds = DruidDataSourceFactory.createDataSource(properties);
		
		for (int i = 0; i < 11; i++) {
			Connection conn = ds.getConnection();
			System.out.println("第" + (i+1) + "个连接对象是：" + conn);
			if (i==4) {
				conn.close();   //释放其中一个连接，会出现重用的连接对象
			}
		}
	}
}

