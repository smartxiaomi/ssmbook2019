-- 创建用户表
CREATE TABLE tbl_user (
	userid INT PRIMARY KEY,
	uname VARCHAR (10),
	upassword VARCHAR (16)
) ENGINE = INNODB

-- 添加数据
insert into tbl_user(Userid,uname,upassword)
values(1,'jack','abcdef');
insert into tbl_user(Userid,uname,upassword)
values(2,'rose','abcdef');
