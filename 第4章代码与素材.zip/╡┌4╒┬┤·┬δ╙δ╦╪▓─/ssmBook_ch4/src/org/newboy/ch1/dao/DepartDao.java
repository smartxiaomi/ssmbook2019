package org.newboy.ch1.dao;

import java.util.List;

import org.newboy.ch4.entity.Depart;

public interface DepartDao {
	
	//
	public List<Depart> getAllDepart();
	
	//
	public Depart getDepartById(int dno);
	

}
