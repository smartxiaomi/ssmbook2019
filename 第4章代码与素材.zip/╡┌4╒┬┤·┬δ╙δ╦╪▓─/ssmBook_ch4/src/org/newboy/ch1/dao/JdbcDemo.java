package org.newboy.ch1.dao;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class JdbcDemo {
	// 连接数据库服务器的地址
	final static String URL = "jdbc:mysql://localhost:3306/mydb";
	final static String DRIVER_CLASS = "com.mysql.jdbc.Driver";
	final static String UNAME = "root";
	final static String UPASS = "123456";

	/**
	 * @param args
	 * @throws SQLException
	 */
	public static void main(String[] args) {
		executeInsert(); // 执行插入数据
		executeQuery(); // 执行查询
	}

	/**
	 * 执行添加功能
	 */
	public static void executeInsert() {
		Connection conn = null;
		Statement stmt = null;
		try {

			Class.forName(DRIVER_CLASS);
			conn = DriverManager.getConnection(URL, UNAME, UPASS);
			stmt = conn.createStatement();
			
			String sql = "insert into DEPT(DEPTNO,DNAME,LOC)values(100,'研发部','广州')";
			int row = stmt.executeUpdate(sql);
			if (row > 0) {
				System.out.println("插入成功");
			} else {
				System.out.println("插入失败ִ");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * 执行查询的方法
	 */
	public static void executeQuery() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName(DRIVER_CLASS);
			conn = DriverManager.getConnection(URL, UNAME, UPASS);
			stmt = conn.createStatement();
			String sql = "select DEPTNO,DNAME,LOC from DEPT";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int dno = rs.getInt("deptno"); //
				String dname = rs.getString("dname");
				String loc = rs.getString("loc");
				System.out.println("部门编号:" + dno + ", 部门名称：" + dname + ", 所在位置：" + loc);

			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
	}

}
