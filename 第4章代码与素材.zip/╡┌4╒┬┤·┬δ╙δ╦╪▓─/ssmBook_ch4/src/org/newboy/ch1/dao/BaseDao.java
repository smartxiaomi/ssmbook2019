package org.newboy.ch1.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BaseDao {
	//这里附加了额外的参数，用来指定数据传输的编码格式
	private final static String URL = "jdbc:mysql://localhost:3306/mydb?useUnicode=true&characterEncoding=utf-8";
	private final static String DRIVER_CLASS = "com.mysql.jdbc.Driver";
	private final static String UNAME = "root";
	private final static String UPASS = "123456";
	protected Connection con;
	protected PreparedStatement ps;
	protected ResultSet rs;

	// 1.取得数据连接 @return Connection
	public Connection getCon() {
		try {
			Class.forName(DRIVER_CLASS);
			con = DriverManager.getConnection(URL, UNAME, UPASS);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	// 2.关闭数据连接相关对象
	public static void closeAll(ResultSet rs, Statement st, Connection con) {

		try {
			if (rs != null)
				rs.close();
			if (st != null)
				st.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 3.执行增，删，改操作
	 */
	public int executeSQL(String sql, Object[] param) {
		int rows = 0;
		try {
			con = getCon();
			ps = con.prepareStatement(sql);
			if (param != null) {
				for (int i = 0; i < param.length; i++) {
					// 数据库兼容其它类型转为为string型
					ps.setString(i + 1, param[i].toString());
				}
			}
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeAll(null, ps, con);
		}
		return rows;
	}

}