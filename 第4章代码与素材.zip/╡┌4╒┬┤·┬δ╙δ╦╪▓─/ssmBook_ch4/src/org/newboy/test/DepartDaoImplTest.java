package org.newboy.test;

import java.util.List;

import org.newboy.ch1.dao.DepartDao;
import org.newboy.ch1.dao.DepartDaoImpl;
import org.newboy.ch1.dao.UserDao;
import org.newboy.ch1.dao.UserDaoImpl;
import org.newboy.ch4.entity.Depart;
import org.newboy.ch4.entity.User;

public class DepartDaoImplTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DepartDao departDao =new DepartDaoImpl();
		List<Depart> list=departDao.getAllDepart();
         for (Depart depart : list) {
        	
			System.out.println(depart.getDname());
		}
	}

}
