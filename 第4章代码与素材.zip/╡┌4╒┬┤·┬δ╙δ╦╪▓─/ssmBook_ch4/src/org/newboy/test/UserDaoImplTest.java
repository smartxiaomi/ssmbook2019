package org.newboy.test;

import org.newboy.ch1.dao.UserDao;
import org.newboy.ch1.dao.UserDaoImpl;
import org.newboy.ch4.entity.User;

public class UserDaoImplTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		UserDao userdao =new UserDaoImpl();
		User user = new User("101","rose","123456");
		 int row =userdao.saveUser(user);
		if(row>0){
			System.out.println("添加成功");
		}else{
			System.out.println("添加失败");
		}
		
		User u=userdao.getUserByNamepwd("rose", "123456");
		if(u!=null){
          System.out.println("查询的用户ID:"+u.getUid());
		}else{
			System.out.println("用户名或密码错误");
		}
	}

}
