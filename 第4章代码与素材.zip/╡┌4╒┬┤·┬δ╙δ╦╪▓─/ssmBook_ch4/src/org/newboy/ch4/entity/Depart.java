package org.newboy.ch4.entity;

public class Depart {

	private int dno;      // 
	private String dname; // 
	private String location;//ڵ�ַ
	
	
	public Depart(int dno, String dname, String location) {
		this.dno = dno;
		this.dname = dname;
		this.location = location;
	}
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	

}
