package org.newboy.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;


public class HelloController2 implements Controller {

	//返回ModelAndView对象
	public ModelAndView handleRequest(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		//向request域中放入1条信息，给前端jsp用
		request.setAttribute("message", "hello,springmvc");
		//返回jsp的路径
		return new ModelAndView("hello");
	}
}