package org.newboy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;


public class MyInterceptor implements HandlerInterceptor {

	
	//前置处理方法 ，返回假表示不再向下执行，真表示继续请求
	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler) throws Exception {
		System.out.println("拦截器1---前置方法");
		
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest req, HttpServletResponse resp,
			Object handler, ModelAndView mv) throws Exception {
		System.out.println("拦截器1---后置方法");
	}

	@Override
	public void afterCompletion(HttpServletRequest req, HttpServletResponse resp,
			Object handler, Exception ex) throws Exception {
		System.out.println("拦截器1---afterComplete方法");

	}

}
