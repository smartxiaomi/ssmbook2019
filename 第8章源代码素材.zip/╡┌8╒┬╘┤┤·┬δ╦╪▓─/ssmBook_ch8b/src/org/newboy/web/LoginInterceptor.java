package org.newboy.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.newboy.ch7.entity.Member;
import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.portlet.HandlerInterceptor;

import org.springframework.web.servlet.ModelAndView;

public class LoginInterceptor implements HandlerInterceptor {

	// 前置处理方法 ，返回假表示不再向下执行，真表示继续请求
	@Override
	public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler) throws Exception {
		// 获取请求的URI
		String uri = req.getRequestURI();
		// 如果请求的路径包含login，即使没有登录也可以直接访问
		if (uri.indexOf("/login") >= 0) {
			return true;
		} else {
			// 否则判断Session
			HttpSession session = req.getSession();
			Member member = (Member) session.getAttribute("LOGIN_Member");
			if (member == null) { // 未登录用户，提示并跳转到登录页面
				req.setAttribute("info", "未登录，请先登录");
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
				return false;
			} else {
				// 已登录用户，继续原来的请求
				return true;
			}
		}
	}

	@Override
	public void postHandle(HttpServletRequest req, HttpServletResponse resp, Object handler, ModelAndView mv) throws Exception {
		// 什么都不用做
	}

	@Override
	public void afterCompletion(HttpServletRequest req, HttpServletResponse resp, Object handler, Exception ex) throws Exception {
		// 什么都不用做
	}

}
