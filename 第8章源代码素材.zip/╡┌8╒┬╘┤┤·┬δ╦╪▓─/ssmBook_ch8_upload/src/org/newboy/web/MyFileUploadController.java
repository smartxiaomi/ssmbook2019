package org.newboy.web;


import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
@Controller
public class MyFileUploadController {
	@RequestMapping("uploadAction.htm")
	public String handleUpload(@RequestParam("filename") MultipartFile file,
			HttpServletRequest request) {
		
		if(!file.isEmpty()){
			//找到文件上传路径
			String newFilepath=request.getServletContext().getRealPath("/upload/");
			System.out.println("filePath:"+newFilepath);
			File filePath =new File(newFilepath);
			if(filePath.exists()){
				filePath.mkdirs();//如果文件夹不存在，则创建文件夹
			}
			//新建1个随机文件名字，使用随机数
			String randomFileName=UUID.randomUUID()+""+file.getOriginalFilename();
			File destFile =new File(filePath.getAbsolutePath()+"\\"+randomFileName);
		
			try {
				destFile.createNewFile();
				file.transferTo(destFile); //复制文件
			} catch (IllegalStateException e) {
				e.printStackTrace();
				return "uploadFail";//上传失败
			} catch (IOException e) {
				e.printStackTrace();
				return "uploadFail";//上传失败
			}
			return "success";//上传成功
		}else{
			return "uploadFail";//上传失败
		}
	}

}
