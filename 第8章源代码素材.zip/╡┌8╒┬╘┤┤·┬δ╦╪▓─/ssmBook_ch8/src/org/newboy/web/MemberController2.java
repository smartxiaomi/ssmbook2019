package org.newboy.web;

import java.util.ArrayList;
import java.util.List;

import org.newboy.ch7.entity.Member;
import org.newboy.ch7.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/ch8")
public class MemberController2 {
	
	@Autowired
	private MemberService memberService;
	
	
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	
	@RequestMapping(value="/user/get.htm")
	@ResponseBody
	public Member selectById(@RequestParam String mid){
		Member member =memberService.get(mid);
		return member;
	}
	
	@RequestMapping("/user/add.htm")
	public String addMember(Member member){
		//模拟添加会员的服务方法
	System.out.println("添加会员成功....");
	memberService.add(member);
		return "redirect:list.htm";
	}
	
	@RequestMapping("/user/remove.htm")
	public String removeMember(){
		//模拟删除会员的服务方法
		System.out.println("删除会员成功....");
		return "redirect:list.htm";
	}
	
	@RequestMapping("/user/list.htm")
	public ModelAndView listMember(){
		//模拟查询并会员的服务方法
		System.out.println("显示会员成功....");
		List<Member> memberList =new ArrayList<Member>();
	
		memberList=memberService.list();
		//返回视图名为list,对应list.jsp文件
		return new ModelAndView("list","memberList",memberList);
	}
	

}
