-- 创建数据库
create database mybatis;

use mybatis;

-- 创建部门表
create table depart (
	depart_id int primary key auto_increment,  -- 主键自动增长
	depart_name varchar(20), -- 部门的名字
	description varchar(100)  -- 部门说明
);

-- 创建员工表
create table employee(
	id int primary key auto_increment,  -- 主键自动增长
	name varchar(20), -- 员工的名字
	gender boolean,  -- 性别
	birthday date,  -- 生日
	depart_id int ,
	-- 创建外键约束
	constraint fk_emp_dept  foreign key (depart_id) references depart(depart_id)
);

select * from depart;