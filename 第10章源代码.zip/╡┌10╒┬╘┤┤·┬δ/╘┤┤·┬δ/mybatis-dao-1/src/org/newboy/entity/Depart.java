package org.newboy.entity;

/**
 * ����ʵ����
 * 
 * @author NewBoy
 */
public class Depart {

	public Depart(int departId, String departName, String description) {
		super();
		this.departId = departId;
		this.departName = departName;
		this.description = description;
	}

	public Depart() {
		super();
	}
	
	@Override
	public String toString() {
		return "Depart [departId=" + departId + ", departName=" + departName + ", description=" + description + "]";
	}

	private int departId;
	private String departName;
	private String description;

	public int getDepartId() {
		return departId;
	}

	public void setDepartId(int departId) {
		this.departId = departId;
	}

	public String getDepartName() {
		return departName;
	}

	public void setDepartName(String departName) {
		this.departName = departName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
