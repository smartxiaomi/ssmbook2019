package org.newboy.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.newboy.entity.Depart;
import org.newboy.utils.SqlSessionUtils;

/**
 * ����DAO��ʵ����
 */
public class DepartDaoImpl implements DepartDao {

	@Override
	public int addDepart(Depart depart) {
		//ͨ��������õ��Ự����
		SqlSession sqlSession = SqlSessionUtils.getSqlSession();
		int row = sqlSession.insert("org.newboy.dao.DepartDao.addDepart", depart);
		//�ύ���񣬲��ҹرջỰ
		SqlSessionUtils.commitAndClose();
		return row;
	}

	@Override
	public int updateDepart(Depart depart) {
		SqlSession sqlSession = SqlSessionUtils.getSqlSession();
		int row = sqlSession.insert("org.newboy.dao.DepartDao.updateDepart", depart);
		SqlSessionUtils.commitAndClose();
		return row;
	}

	@Override
	public int deleteDepart(int departId) {
		SqlSession sqlSession = SqlSessionUtils.getSqlSession();
		int row = sqlSession.insert("org.newboy.dao.DepartDao.deleteDepart", departId);
		SqlSessionUtils.commitAndClose();
		return row;
	}


	@Override
	public List<Depart> findAllDeparts() {
		// ͨ���Զ���Ĺ�����õ��Ự
		SqlSession sqlSession = SqlSessionUtils.getSqlSession();
		List<Depart> departs = sqlSession.selectList("org.newboy.dao.DepartDao.findAllDeparts");
		//�رջỰ����
		SqlSessionUtils.commitAndClose();
		return departs;
	}

}
