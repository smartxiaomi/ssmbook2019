package org.newboy.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.newboy.entity.Depart;
import org.newboy.utils.SqlSessionUtils;

/**
 * ����DAO��ʵ����
 */
public class DepartDaoImpl implements DepartDao {

	@Override
	public long findCount() {
		// ͨ���Զ���Ĺ�����õ��Ự
		SqlSession sqlSession = SqlSessionUtils.getSqlSession();
		return sqlSession.selectOne("findCount");
	}

	@Override
	public List<Depart> findByPage(int pageIndex, int pageSize) {
		// ͨ���Զ���Ĺ�����õ��Ự
		SqlSession sqlSession = SqlSessionUtils.getSqlSession();
		Map<String, Object> map = new HashMap<>();
		map.put("pageIndex", pageIndex);
		map.put("pageSize", pageSize);
		return sqlSession.selectList("findByPage", map);
	}

}
