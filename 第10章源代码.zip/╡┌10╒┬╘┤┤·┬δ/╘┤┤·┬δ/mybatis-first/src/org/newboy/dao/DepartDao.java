package org.newboy.dao;

import org.apache.ibatis.session.SqlSession;
import org.newboy.entity.Depart;

public class DepartDao extends BaseDao {
	
	public int addDepart(Depart depart) {
		int row = getSqlSession().insert("addDepart", depart);
		commitAndClose();
		return row;
	}
	
	public int updateDepart(Depart depart) {
		return getSqlSession().insert("updateDepart", depart);
	}
	
	public int deleteDepart(int departId) {
		return getSqlSession().insert("deleteDepart", departId);
	}

}
