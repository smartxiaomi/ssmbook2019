-- 创建多对多的关系
-- 创建学生表
create table student(
	id int primary key auto_increment,
	stu_name varchar(20)
)

select * from student;
insert into student values (null, '张三'),(null, '李四'),(null, '王五');

-- 创建课表表
create table course(
	id int primary key auto_increment,
	course_name varchar(20)
)
insert into course values (null, '语文'),(null, '音乐'),(null, '体育');

select * from course

-- 创建关系表
create table student_course (
	student_id int ,
	course_id int,
	-- 创建复合主键
	primary key(student_id, course_id),
	-- 创建外键
	foreign key (student_id) references student(id),
	foreign key (course_id) references course(id)
)
-- 插入两者的关系
insert into student_course values (1,1),(1,3),(2,2),(2,3),(3,1);
select * from student_course;
-- 查询1号学生的信息
select * from student where id = 1;

-- 查询指定学生和他所学的课程信息
select s.*, c.* from student s inner join student_course sc inner join  course c on s.id = sc.student_id and c.id = sc.course_id where s.id = 1;

select c.* from student s inner join student_course sc inner join  course c on s.id = sc.student_id and c.id = sc.course_id where s.id = 1;

select s.* from student s inner join student_course sc inner join  course c on s.id = sc.student_id and c.id = sc.course_id where c.id = 1;

select s.*, c.* from student s inner join student_course sc inner join  course c on s.id = sc.student_id and c.id = sc.course_id where s.id = 2;


