package org.newboy.entity;

/**
 * 封装查询条件
 * @author NewBoy
 */
public class Condition {
	
	private String name;  //姓名，要使用模糊查询
	private String gender;  //性别：男或女
	private Integer min;  //最小年龄，注：这里使用的是包装类，而不是原始类型
	private Integer max;  //最大年龄
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Integer getMin() {
		return min;
	}
	public void setMin(Integer min) {
		this.min = min;
	}
	public Integer getMax() {
		return max;
	}
	public void setMax(Integer max) {
		this.max = max;
	}
	

}
