package org.newboy.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.newboy.entity.Condition;
import org.newboy.entity.Customer;

/**
 * DAO的测试类
 * @author NewBoy
 *
 */
public class TestCustomer {
	
	//创建静态工厂类，只创建1次
	private static SqlSessionFactory factory;
	//创建会话类，每次操作都创建1个
	private SqlSession sqlSession;
	
	//类加载之前运行1次
	@BeforeClass
	public static void  beforeClass() {
		try {
			InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
			factory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//每个测试方法执行前运行1次，得到一个会话
	@Before
	public void before() {
		sqlSession = factory.openSession();
	}
	
	//每个测试方法执行后运行1次，提交事务，关闭会话
	@After
	public void after() {
		sqlSession.commit();
		sqlSession.close();
	}
	
	/**
	 * 根据条件查询客户
	 */
	@Test
	public void testFindByCondition() {
		//创建封装条件的JavaBean
		Condition condition = new Condition();
		//没有查询条件，相当于得到所有的记录
		List<Customer> customers = sqlSession.selectList("org.newboy.dao.CustomerDao.findByCondition", condition);
		for (Customer customer : customers) {
			System.out.println(customer);
		}
		//封装性别为女
		condition.setGender("女");
		customers = sqlSession.selectList("org.newboy.dao.CustomerDao.findByCondition", condition);
		for (Customer customer : customers) {
			System.out.println(customer);
		}
		//再加多一个条件，年龄30岁以上的(含)
		condition.setMin(30);
		customers = sqlSession.selectList("org.newboy.dao.CustomerDao.findByCondition", condition);
		for (Customer customer : customers) {
			System.out.println(customer);
		}
		//再加多一个条件，年龄在40以下的(含)
		condition.setMax(40);
		customers = sqlSession.selectList("org.newboy.dao.CustomerDao.findByCondition", condition);
		for (Customer customer : customers) {
			System.out.println(customer);
		}
		//再加多一个条件，名字包含"天"字的
		condition.setName("天");
		customers = sqlSession.selectList("org.newboy.dao.CustomerDao.findByCondition", condition);
		for (Customer customer : customers) {
			System.out.println(customer);
		}
	}
	
/**
 * 查询符合条件的记录有多少行
 */
@Test
public void testFindCount() {
	Condition condition = new Condition();
	condition.setGender("女");
	condition.setMax(40);
	//因为指定的查询参数是map，所以要将查询条件放到map中
	HashMap<String, Object> map = new HashMap<>();
	map.put("condition", condition);
	long count = (Long) sqlSession.selectOne("org.newboy.dao.CustomerDao.findCount", map);
	System.out.println("符合条件的记录数：" + count);
}
	
/**
 * 查询符合条件的一页数据
 */
@Test
public void testFindPage() {
	Condition condition = new Condition();
	condition.setGender("女");
	condition.setMax(40);
	//因为指定的查询参数是map，所以要将查询条件放到map中
	HashMap<String, Object> map = new HashMap<>();
	map.put("condition", condition);
	//分页参数也放在里面：每页显示3条记录，显示第2页的数据
	map.put("pageIndex", 3);
	map.put("pageSize", 3);
	List<Customer> list = sqlSession.selectList("org.newboy.dao.CustomerDao.findPage", map);
	for (Customer customer : list) {
		System.out.println(customer);
	}
}

/**
 * 删除多个客户
 */
@Test
public void testDeleteAll() {
	int row = sqlSession.delete("org.newboy.dao.CustomerDao.deleteAll", new int[] {1,2,3});
	System.out.println("删除" + row + "条记录");
}

/**
 * 批量添加客户
 */
@Test
public void testSaveAll() {
	//创建三个要添加的客户
	List<Customer> customers = new ArrayList<>();
	//注：要有相应的Customer构造方法
	customers.add(new Customer("白骨精","女",25,"餐厅经理","13909870659","bai@newboy.org"));
	customers.add(new Customer("牛魔王","男",35,"水电工","13970694659","niumowang@newboy.org"));
	customers.add(new Customer("嫦娥","女",22,"行政总监","13409769072","change@newboy.org"));
	int row = sqlSession.insert("org.newboy.dao.CustomerDao.saveAll", customers);
	System.out.println("添加了" + row + "条记录");
}

/**
 * 以Customer做为查询条件，以其中的某个属性值做为查询条件
 * 如果属性值不为空，则使用这个条件查询。
 * 如果所有属性都不满足，则使用id做为条件查询
 */
@Test
public void testFindByChoose() {
	//创建一个Customer做为查询条件
	Customer customer = new Customer();
	customer.setId(4);
	//因为所有的条件为空，所以使用id做为查询条件
	List<Customer> list = sqlSession.selectList("org.newboy.dao.CustomerDao.findByChoose", customer);
	for (Customer c : list) {
		System.out.println(c);
	}
	//使用性别做为查询条件
	customer.setGender("女");
	list = sqlSession.selectList("org.newboy.dao.CustomerDao.findByChoose", customer);
	for (Customer c : list) {
		System.out.println(c);
	}
	//使用姓名做为查询条件
	customer.setName("娜");
	list = sqlSession.selectList("org.newboy.dao.CustomerDao.findByChoose", customer);
	for (Customer c : list) {
		System.out.println(c);
	}
}

}
