package org.newboy.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.newboy.entity.Depart;
import org.newboy.entity.Employee;

/**
 * 测试查询缓存
 * @author NewBoy
 */
public class TestCache {
	
	//静态的会话工厂对象
	private static SqlSessionFactory sqlSessionFactory;
	
	//在静态代码块中，类加载的时候创建会话工厂
	static {
		InputStream inputStream;
		try {
			//读取配置文件得到输入流
			inputStream = Resources.getResourceAsStream("mybatis-config.xml");
			// 创建会话工厂：SqlSessionFactory
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 得到会话对象
	 * @return
	 */
	public SqlSession getSqlSession() {
		return sqlSessionFactory.openSession();
	}
	
	//程序入口
	public static void main(String[] args) throws IOException {
		TestCache testCache = new TestCache();
		System.out.println("--- 第1次查询 ---");
		//第1次查询部门
		testCache.findDepart();
		System.out.println("--- 第2次查询 ---");
		//第2次查询部门，与第1次查询不是同一个会话对象
		testCache.findDepart();
	}
	
	/**
	 * 查询1个部门
	 */
	public void findDepart() {
		//得到会话对象
		SqlSession sqlSession = getSqlSession();
		//查询得到部门
		Depart depart = sqlSession.selectOne("org.newboy.dao.DepartDao.selectDepart",1);
		System.out.println("部门名：" + depart.getDepartName());
		//得到这个部门下所有的员工
		List<Employee> employees = depart.getEmployees();
		for (Employee employee : employees) {
			//输出员工的名字
			System.out.println("员工名：" + employee.getName());
		}
		//提交事务
		sqlSession.commit();
		//关闭会话
		sqlSession.close();
	}

}
