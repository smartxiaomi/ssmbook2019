package org.newboy.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.newboy.entity.Depart;
import org.newboy.entity.Employee;

/**
 * DAO的测试类
 * @author NewBoy
 *
 */
public class TestDao {
	
	//创建静态工厂类，只创建1次
	private static SqlSessionFactory factory;
	//创建会话类，每次操作都创建1个
	private SqlSession sqlSession;
	
	//类加载之前运行1次
	@BeforeClass
	public static void  beforeClass() {
		try {
			InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
			factory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//每个测试方法执行前运行1次，得到一个会话
	@Before
	public void before() {
		sqlSession = factory.openSession();
	}
	
	//每个测试方法执行后运行1次，提交事务，关闭会话
	@After
	public void after() {
		sqlSession.commit();
		sqlSession.close();
	}
	
	/**
	 * 查询某个部门的所有员工，同时输出部门的名字
	 */
	@Test
	public void testFindEmployees() {
		//第1个参数：指定映射文件中的命名空间和查询id，第2个参数是部门的id
		List<Employee> list = sqlSession.selectList("org.newboy.dao.EmployeeDao.selectEmployees", 1);
		for (Employee employee : list) {
			System.out.println("姓名：" + employee.getName() + "，生日：" + employee.getBirthday() + "，部门名:" + employee.getDepart().getDepartName());
		}
	}
	
	/**
	 * 查询所有的员工
	 */
	@Test
	public void testFindDeparts() {
		List<Depart> list = sqlSession.selectList("org.newboy.dao.DepartDao.selectAllDeparts");
		for (Depart depart : list) {
			System.out.println("部门名：" + depart.getDepartName());
			System.out.println("---------");
			//得到这个部门下所有的员工
			List<Employee> employees = depart.getEmployees();
			for (Employee employee : employees) {
				System.out.println(employee);
			}
		}
	}
	
/**
 * 通过部门id查询1个部门的信息
 */
@Test
public void testFindDepart() {
	Depart depart = sqlSession.selectOne("org.newboy.dao.DepartDao.selectDepart",1);
	System.out.println("部门名：" + depart.getDepartName());
	//得到这个部门下所有的员工
	List<Employee> employees = depart.getEmployees();
	for (Employee employee : employees) {
		System.out.println("员工名：" + employee.getName());
	}
}
	
}
