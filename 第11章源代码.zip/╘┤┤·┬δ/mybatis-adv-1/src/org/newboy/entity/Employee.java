package org.newboy.entity;

import java.sql.Date;

/**
 * 员工实体类
 * 
 * @author NewBoy
 */
public class Employee {

	private int id; // 编号
	private String name; // 姓名
	private boolean gender; // 性别
	private Date birthday; // 生日
	private Depart depart; // 所在部门对象，指定多对一的关联对象
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", gender=" + gender + ", birthday=" + birthday + "]";
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isGender() {
		return gender;
	}

	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public Depart getDepart() {
		return depart;
	}

	public void setDepart(Depart depart) {
		this.depart = depart;
	}

}
