package org.newboy.entity;

import java.util.List;

/**
 * 部门的实体类
 * 
 * @author NewBoy
 */
public class Depart {
	
	private int departId;
	private String departName;
	private String description;
	private List<Employee> employees;
	
	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public Depart(int departId, String departName, String description) {
		super();
		this.departId = departId;
		this.departName = departName;
		this.description = description;
	}

	public Depart() {
		super();
	}

	@Override
	public String toString() {
		return "Depart [departId=" + departId + ", departName=" + departName + ", description=" + description + "]";
	}

	public int getDepartId() {
		return departId;
	}

	public void setDepartId(int departId) {
		this.departId = departId;
	}

	public String getDepartName() {
		return departName;
	}

	public void setDepartName(String departName) {
		this.departName = departName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
