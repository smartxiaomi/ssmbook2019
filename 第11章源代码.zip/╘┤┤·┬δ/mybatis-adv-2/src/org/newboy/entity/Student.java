package org.newboy.entity;

import java.util.Set;

/**
 * 学生类
 * @author NewBoy
 */
public class Student {
	
	private int id;
	private String stuName;  //姓名
	private Set<Course> courses;  //所选课程对象的集合
	
	@Override
	public String toString() {
		return "Student [id=" + id + ", stuName=" + stuName + ", courses=" + courses + "]";
	}

	public Set<Course> getCourses() {
		return courses;
	}

	public void setCourses(Set<Course> courses) {
		this.courses = courses;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}


}
