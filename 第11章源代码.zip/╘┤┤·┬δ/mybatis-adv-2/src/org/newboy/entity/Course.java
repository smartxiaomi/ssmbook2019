package org.newboy.entity;

import java.util.Set;

/**
 * 课程对象
 * @author NewBoy
 */
public class Course {

	private int id;
	private String courseName; // 课程名
	private Set<Student> students; // 选择这门课程的学生集合
	
	@Override
	public String toString() {
		return "Course [id=" + id + ", courseName=" + courseName + ", students=" + students + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

}
