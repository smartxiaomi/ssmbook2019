package org.newboy.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Set;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.newboy.entity.Course;
import org.newboy.entity.Student;

/**
 * DAO的测试类
 * @author NewBoy
 *
 */
public class TestDao {
	
	//创建静态工厂类，只创建1次
	private static SqlSessionFactory factory;
	//创建会话类，每次操作都创建1个
	private SqlSession sqlSession;
	
	//类加载之前运行1次
	@BeforeClass
	public static void  beforeClass() {
		try {
			InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
			factory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//每个测试方法执行前运行1次，得到一个会话
	@Before
	public void before() {
		sqlSession = factory.openSession();
	}
	
	//每个测试方法执行后运行1次，提交事务，关闭会话
	@After
	public void after() {
		sqlSession.commit();
		sqlSession.close();
	}
	
	/**
	 * 查询指定学生所学的课程
	 */
	@Test
	public void testFindStudent() {
		// 得到1号学生
		Student s1 = sqlSession.selectOne("org.newboy.dao.StudentDao.findStudentById", 1);
		System.out.println("学生：" + s1.getStuName());
		System.out.println("课程：");
		// 输出1号学生所学的课程
		Set<Course> courses1 = s1.getCourses();
		for (Course course : courses1) {
			System.out.println(course.getCourseName());
		}
		// 得到2号学生
		Student s2 = sqlSession.selectOne("org.newboy.dao.StudentDao.findStudentById", 2);
		System.out.println("学生：" + s2.getStuName());
		System.out.println("课程：");
		// 输出2号学生所学的课程
		Set<Course> courses2 = s2.getCourses();
		for (Course course : courses2) {
			System.out.println(course.getCourseName());
		}
	}
	
	/**
	 * 查询学习某门课程的学生有哪些
	 */
	@Test
	public void testFindCourse() {
		//查询1号课程
		Course course = sqlSession.selectOne("org.newboy.dao.CourseDao.findCourseById", 1);
		System.out.println("课程名：" + course.getCourseName());
		System.out.println("学习这门课程的学生：");
		//得到学习这门课程的学生
		Set<Student> students = course.getStudents();
		for (Student student : students) {
			System.out.println(student.getStuName());
		}
	}
}
