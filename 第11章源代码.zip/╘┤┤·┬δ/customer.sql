drop table customer;
-- 客户表
create table customer(
	id int primary key auto_increment,
	name varchar(20), -- 姓名
	gender char(1), -- 性别
	age int,            -- 年龄
	title varchar(20),  -- 职位
	phone varchar(20),   -- 电话
	email varchar(20)    -- 邮箱
);
-- 插入客户数据
insert into customer(name,gender,age,title,phone,email) values ('陈宏子','男',21,'工程师','15815811688','cheng@126.com');
insert into customer(name,gender,age,title,phone,email) values ('秦婷婷','女',25,'工程师','15815888802','tingting@newboy.com');
insert into customer(name,gender,age,title,phone,email) values ('折蓉蓉','女',30,'网络管理','13496853333','zherong@163.com');
insert into customer(name,gender,age,title,phone,email) values ('曹丽娜','女',26,'软件开发','13422095333','lina@qq.com');
insert into customer(name,gender,age,title,phone,email) values ('李娜','女',46,'咨询顾问','13422089706','lina@sohu.com');
insert into customer(name,gender,age,title,phone,email) values ('姜钰','男',49,'软件开发工程师','13425869513','jiang@qq.com');
insert into customer(name,gender,age,title,phone,email) values ('魏天霞','女',38,'软件开发工程师','13978605934','tianxia@126.com');

select * from customer;
