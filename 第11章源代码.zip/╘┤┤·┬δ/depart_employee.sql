-- 删除原有的表
drop table employee;
drop table depart;

-- 创建部门表
create table depart (
	depart_id int primary key auto_increment,  -- 主键自动增长
	depart_name varchar(20), -- 部门的名字
	description varchar(100)  -- 部门说明
);

-- 创建员工表
create table employee(
	id int primary key auto_increment,  -- 主键自动增长
	name varchar(20), -- 员工的名字
	gender boolean,  -- 性别
	birthday date,  -- 生日
	depart_id int ,
	-- 创建外键约束
	constraint fk_emp_dept  foreign key (depart_id) references depart(depart_id)
);

-- 插入1个部门
insert into depart (depart_name, description) values ('取经部', '大唐派往西天取经的小分队');

select * from depart;

-- 插入3个员工
insert into employee (name,gender,birthday,depart_id) values
 ('孙悟空', true, '1985-02-11', 1),('猪八戒', true, '1986-03-06', 1),('沙悟净', true, '1988-04-18', 1);
 
 select * from employee;
